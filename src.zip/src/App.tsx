// import { createBrowserRouter, RouterProvider } from 'react-router'



import { createBrowserRouter, RouterProvider } from 'react-router'
import Layout from './pages/Layout'
import { About } from './pages/About'
import {Home} from './pages/Home'

const router = createBrowserRouter([
    {
        path: '/',
        element: <Layout/>,
        children: [
            {
                index: true,
                element: <About />
            },
            {
                path: 'home',
                element: <Home />
            }
        ]
    }
])

function App() {
    return <RouterProvider router={router} />
}

export default App