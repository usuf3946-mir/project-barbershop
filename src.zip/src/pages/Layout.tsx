import { Link, Outlet } from 'react-router'
function Layout() {
    return (
        <>
            <Link to="/">Crud</Link>
            <Link to="/Get">info</Link>
            
            <Outlet />
        </>
    )
}

export default Layout